//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by HexComparerV1.rc
//
#define IDR_ACCELERATOR1                101
#define ID_ENTER                        40001
#define ID_PAGEUP                       40002
#define ID_PAGEDOWN                     40003
#define ID_LINEUP                       40004
#define ID_LINEDOWN                     40005
#define ID_END                          40006
#define ID_BEGIN                        40007

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40009
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
